---PL/SQL Execise---------------------------------------------------------------------------------------------------------------------------------

***ORACLE***
1)Ans:-
		CREATE OR REPLACE PROCEDURE SP_EXECISE_1 is
 
        	v_first_name TEST_INTERN_EMPLOYEES.FIRST_NAME%TYPE;
       		v_dept_name TEST_INTERN_DEPARTMENTS.DEPARTMENT_NAME%TYPE;
	        v_manager_id TEST_INTERN_DEPARTMENTS.MANAGER_ID%TYPE;
		BEGIN
		    select e.first_name,d.department_name,e.manager_id into v_first_name,v_dept_name,v_manager_id 
		    from TEST_INTERN_EMPLOYEES e 
		    left JOIN TEST_INTERN_DEPARTMENTS d
		    on e.department_id=d.DEPARTMENT_ID where e.EMPLOYEE_ID=130;
    
		    DBMS_OUTPUT.PUT_LINE('---------------------------------');
		    DBMS_OUTPUT.PUT_LINE('Employee Name:= '||v_first_name);
		    DBMS_OUTPUT.PUT_LINE('Department Name:= '||v_dept_name);
		    DBMS_OUTPUT.PUT_LINE('Manager Id:= '||v_manager_id);
		    DBMS_OUTPUT.PUT_LINE('---------------------------------');

END SP_EXECISE_1;

***MYSQL***
		
		CREATE DEFINER=`mysqldb`@`%` PROCEDURE `SP_EXECISE_1`()
		BEGIN
	
		    declare v_first_name varchar(50);
		    declare v_dept_name varchar(50);
		    declare v_manager_id int(10);
	
		    select e.first_name,d.department_name,e.manager_id into v_first_name,v_dept_name,v_manager_id 
		    from test_intern_employees e 
		    left JOIN test_intern_departments d
		    on e.department_id=d.department_id where e.employee_id=5;
    
		    select concat('First Name:=',v_first_name,'\nDepartment Name:= ',v_dept_name,
		    '\nManager Id:= ',v_manager_id); --concate the output
   
    
		END



***ORACLE***
2)Ans:-
	Declare
        	v_year NUMBER;
        	v_month VARCHAR2(10);
	        v_max NUMBER;
        
        
        	CURSOR cur_max_num_emp_join IS
        	    SELECT TO_CHAR(HIRE_DATE,'YY'),TO_CHAR(HIRE_DATE,'MM'),COUNT(EMPLOYEE_ID)
        	    FROM TEST_INTERN_EMPLOYEES GROUP BY TO_CHAR(HIRE_DATE,'YY'),TO_CHAR(HIRE_DATE,'MM');
        
	BEGIN

	    open cur_max_num_emp_join; -- open cursor
	    FETCH cur_max_num_emp_join into v_year,v_month,v_max;
	    while(cur_max_num_emp_join%FOUND)
	    loop
	    -- fetch the next row in the active set
	            DBMS_OUTPUT.PUT_LINE('---------------------------------');
	            DBMS_OUTPUT.PUT_LINE('Year:= '||v_year);
	            DBMS_OUTPUT.PUT_LINE('Month:= '||v_month);
	            DBMS_OUTPUT.PUT_LINE('Employee Id:= '||v_max);
	            DBMS_OUTPUT.PUT_LINE('---------------------------------');
	    end loop;
	    close cur_max_num_emp_join; -- close the cursor
	EXCEPTION
	    WHEN invalid_cursor then --Exception Handle
        	DBMS_OUTPUT.PUT_LINE('Invalid Cursor Found');
	END;


***MYSQL***

	CREATE DEFINER=`mysqldb`@`%` PROCEDURE `SP_Execise_2`()
	
	BEGIN
		declare done int default false;
		declare v_year int(10);
	        declare v_month varchar(20);
		declare v_max int(10);
		
	        declare max_num_emp_join cursor for --Declare Cursor
		        SELECT year(hire_date) as 'Year',month(hire_date) as 'Month',COUNT(employee_id) as 'Total Employee'
			FROM test_intern_employees GROUP BY year(hire_date),month(hire_date);
	        declare continue handler --Handle cursor
			for not found set done=true;
        
        	open max_num_emp_join;-- open cursor
        
        	get_emp:loop
        
			fetch max_num_emp_join into v_year,v_month,v_max; -- fetch the next row in the active set
        
			if done=true then
				leave get_emp; -- if done is true then cursor is exit
			end if;
        
			select concat('Year:=',v_year,' Month:=',v_month,' Total Employee:=',v_max,'\n');
        	end loop get_emp;
        	close max_num_emp_join; --end cursor
	END




***ORACLE***
3)Ans:-

	DECLARE
    		v_salary number;
		temp_salary number;
		fname VARCHAR2(10);
   		v_fname varchar2(10);

	    CURSOR cur_salary_update is
        	select first_name,EMPSALARY from TEST_INTERN_EMPLOYEES;

	BEGIN
	    fname:='jeo';
	    open cur_salary_update;
	    FETCH cur_salary_update into v_fname,v_salary;
    
	    while (cur_salary_update%found) 
	    loop
	        IF (v_fname=fname) THEN
	            select EMPSALARY into temp_salary from TEST_INTERN_EMPLOYEES where first_name=fname;
	            update TEST_INTERN_EMPLOYEES set EMPSALARY=temp_salary WHERE EMPLOYEE_ID=130; 
	            DBMS_OUTPUT.PUT_LINE('Set the Jeo Salary');
            
	        ELSIF (v_fname=fname) then
	            select min(EMPSALARY) into temp_salary from TEST_INTERN_EMPLOYEES where first_name=fname;
	            update TEST_INTERN_EMPLOYEES set EMPSALARY=temp_salary WHERE EMPLOYEE_ID=130; 
	            DBMS_OUTPUT.PUT_LINE('Set the least Salary');
	        ELSE
	            select avg(EMPSALARY) into temp_salary from TEST_INTERN_EMPLOYEES;
	            update TEST_INTERN_EMPLOYEES set EMPSALARY=temp_salary WHERE EMPLOYEE_ID=130; 
	            DBMS_OUTPUT.PUT_LINE('Set the Average Salary');
	        END IF;
	        FETCH cur_salary_update into v_fname,v_salary;
	    end loop;
	    CLOSE cur_salary_update;
	end;



***ORACLE***
4)Ans:-
	DECLARE
	    v_job_title varchar2(20);
	    v_emp_name varchar2(20);
    
	    cursor cur_join_emp is --Declare cursor
        	SELECT j.job_title,e.first_name FROM TEST_INTERN_EMPLOYEES e 
        	inner join TEST_INTERN_JOBS j on e.JOB_ID=j.JOB_ID
        	inner join TEST_INTERN_JOB_HISTORY jh on e.JOB_ID=jh.JOB_ID where e.HIRE_DATE=jh.START_DATE;    
	BEGIN
        	open cur_join_emp; --open cursor
        	FETCH cur_join_emp into v_job_title,v_emp_name; --fetch the next row in the active set
        	WHILE (cur_join_emp%found)
        	loop
        	    DBMS_OUTPUT.PUT_LINE('Job Title:='||v_job_title);
        	    DBMS_OUTPUT.PUT_LINE('Employee Name:='||v_emp_name);
        	    
        	    FETCH cur_join_emp into v_job_title,v_emp_name;
        	end loop;
        	CLOSE cur_join_emp; -- close cursor
        	
        	EXCEPTION
        	WHEN invalid_cursor then --Handle the Exception
        	    DBMS_OUTPUT.PUT_LINE('Invalid Cursor Found');
	end;




***ORACLE***
5)Ans:-
		
	


